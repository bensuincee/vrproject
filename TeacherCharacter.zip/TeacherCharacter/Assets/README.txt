﻿TEACHER CHARACTER – INTEGRATION NOTES

Prefab:
- Use TeacherCharacter.prefab

Animator Parameters:
- bool isTalking
- bool isListening
- trigger doExplain

Conversation Flow:
User speaking → SetListening(true)
User silence → SetListening(false)
AI response start → SetTalking(true)
AI response end → SetTalking(false)
Explain intent → PlayExplain()

TTS Binding:
Assign same AudioSource used for TTS playback to:
- TalkFromAudio.audioSource
- BlendshapeMouthDriver.audioSource

Notes:
- Listening animation (Hard Head Nod) Loop ON
- Explain animation Loop OFF
- AudioSource fields intentionally NONE in prefab
