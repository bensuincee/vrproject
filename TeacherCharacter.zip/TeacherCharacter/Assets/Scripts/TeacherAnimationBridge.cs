using UnityEngine;

public class TeacherAnimationBridge : MonoBehaviour
{
    [SerializeField] private Animator animator;

    [Header("Animator Parameter Names")]
    [SerializeField] private string isTalkingParam = "isTalking";
    [SerializeField] private string isListeningParam = "isListening";
    [SerializeField] private string doExplainParam = "doExplain";

    private void Awake()
    {
        if (animator == null)
            animator = GetComponent<Animator>();

        if (animator == null)
            Debug.LogError($"{name}: Animator bulunamad�.");
    }

    // Text veya sesli konu�ma ba�latmak i�in
    public void SetTalking(bool on)
    {
        if (animator == null) return;

        animator.SetBool(isTalkingParam, on);

        if (on)
            animator.SetBool(isListeningParam, false); // �ak��may� engelle
    }

    // Kullan�c� konu�urken �a�r�l�r
    public void SetListening(bool on)
    {
        if (animator == null) return;

        animator.SetBool(isListeningParam, on);

        if (on)
            animator.SetBool(isTalkingParam, false); // �ak��may� engelle
    }

    // Explain animasyonu tetiklemek i�in
    public void PlayExplain()
    {
        if (animator == null) return;

        animator.SetTrigger(doExplainParam);
    }
}
