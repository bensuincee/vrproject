using UnityEngine;

public class BlendshapeMouthDriver : MonoBehaviour
{
    public SkinnedMeshRenderer headRenderer; // Wolf3D_Head'in SkinnedMeshRenderer'�
    public AudioSource audioSource;          // TTS AudioSource (entegrat�r ba�layacak)

    [Header("Blendshape name contains (case-insensitive)")]
    public string mouthOpenContains = "mouthopen";

    [Header("Tuning")]
    [Range(0f, 100f)] public float maxOpenWeight = 80f;
    public float sensitivity = 80f;
    public float smooth = 12f;

    int mouthOpenIndex = -1;
    float current01;
    float[] samples; // alloc yapmamak i�in

    void Start()
    {
        if (headRenderer == null) headRenderer = GetComponentInChildren<SkinnedMeshRenderer>();

        if (audioSource == null)
            Debug.LogWarning($"{name}: AudioSource atanmam��. TTS AudioSource'u Inspector�dan veya kodla ba�lay�n.");

        mouthOpenIndex = FindBlendshapeIndex(headRenderer, mouthOpenContains);

        if (mouthOpenIndex < 0)
            Debug.LogError($"{name}: MouthOpen blendshape bulunamad�. headRenderer do�ru mu? Blendshape ad�n� kontrol et.");

        samples = new float[512];
    }

    void Update()
    {
        if (headRenderer == null || audioSource == null || mouthOpenIndex < 0) return;

        float target01 = 0f;

        if (audioSource.isPlaying)
        {
            audioSource.GetOutputData(samples, 0);

            float sum = 0f;
            for (int i = 0; i < samples.Length; i++) sum += samples[i] * samples[i];
            float rms = Mathf.Sqrt(sum / samples.Length);

            target01 = Mathf.Clamp01(rms * sensitivity);
        }

        current01 = Mathf.Lerp(current01, target01, Time.deltaTime * smooth);
        headRenderer.SetBlendShapeWeight(mouthOpenIndex, current01 * maxOpenWeight);
    }

    int FindBlendshapeIndex(SkinnedMeshRenderer r, string contains)
    {
        if (r == null || r.sharedMesh == null) return -1;

        string key = contains.ToLower().Replace(" ", "");
        var mesh = r.sharedMesh;

        for (int i = 0; i < mesh.blendShapeCount; i++)
        {
            string n = mesh.GetBlendShapeName(i).ToLower().Replace(" ", "");
            if (n.Contains(key)) return i;
        }
        return -1;
    }
}
