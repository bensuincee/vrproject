using UnityEngine;

public class TalkFromAudio : MonoBehaviour
{
    public Animator animator;
    public AudioSource audioSource;

    public string isTalkingParam = "isTalking";
    public string isListeningParam = "isListening";

    private bool warned;

    void Update()
    {
        if (animator == null || audioSource == null)
        {
            if (!warned)
            {
                Debug.LogWarning($"{name}: TalkFromAudio i�in Animator veya AudioSource atanmad�. TTS AudioSource'u ba�lay�n.");
                warned = true;
            }
            return;
        }

        bool talking = audioSource.isPlaying;

        animator.SetBool(isTalkingParam, talking);

        // Konu�urken dinlemeyi kapat (�at��ma �nleme)
        if (talking)
            animator.SetBool(isListeningParam, false);
    }
}
